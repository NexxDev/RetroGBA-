package dev.retrogba.android.render

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

class GameSurface(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawColor(0xFF080B10.toInt())
        paint.color = 0xFF1D2B3A.toInt()
        canvas.drawRoundRect(width * .08f, height * .08f, width * .92f, height * .92f, 18f, 18f, paint)
        paint.color = 0xFFE5EDF7.toInt()
        paint.textAlign = Paint.Align.CENTER
        paint.textSize = 22f
        canvas.drawText("RETROGBA", width / 2f, height / 2f - 10f, paint)
        paint.color = 0xFF9EADBF.toInt()
        paint.textSize = 13f
        canvas.drawText("Pantalla provisional · núcleo pendiente", width / 2f, height / 2f + 18f, paint)
    }
}
